package com.example.maze;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MazeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MazeApplication.class, args);
	}

}
