package com.example.maze;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MazeApplicationTests {

	@Test
	void contextLoads() {
	}

}
